#include<iostream>
#include<string>

using namespace std;

int main(){
	cout<<"Delete this line and put your code here"<<endl;
	return 0;
}
