#include<iostream>
#include<string>

using namespace std;

int main(){
	string name;
	cout<<"Enter your name:"<<endl;
	cin>>name;
	cout<<"Hello "<<name<<"!"<<endl;
}
