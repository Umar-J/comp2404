#include<iostream>
#include<string>

using namespace std;

int main(){
    int x,y;
    cout<<"Please enter 2 integers:";
    cin>>x>>y;
    cout<<"the product of "<< x << " and " << y<< " is "<<x*y<<endl;
}