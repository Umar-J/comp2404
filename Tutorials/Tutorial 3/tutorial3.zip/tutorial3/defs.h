#ifndef DEFS_H
#define DEFS_H
#include <string>
#define MAX_ARRAY 256

#endif