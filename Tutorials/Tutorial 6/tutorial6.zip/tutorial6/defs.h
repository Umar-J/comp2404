#ifndef DEFS_H
#define DEFS_H

const std::string red("\033[0;31m");
const std::string def("\033[0m");

#endif
