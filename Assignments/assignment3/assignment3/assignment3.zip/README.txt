Name: Umar Jan

Student Number: 101270578

Files: 
	CellPhone.cc
	CellPhone.h
	Control.cc
	Control.h
	Entity.cc
	Entity.h
	List.cc
	List.h
	Location.cc
	Location.h
	main.cc
	Makefile
	Message.cc
	Message.h
	Network.cc
	Network.h
	README.txt
	test.cc
	TestControl.cc
	TestControl.h
	Tester.cc
	Tester.h
	Tower.cc
	Tower.h
	umldiagram.pdf
	View.cc
	View.h

Compilation instructions:
	Open terminal in folder, Run "make" command, 

To execute: 	
	use command: ./a3
	use command: ./test