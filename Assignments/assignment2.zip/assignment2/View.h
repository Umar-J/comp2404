#ifndef VIEW_H
#define VIEW_H

#include <iostream>
#include <string>
#include <vector>

using namespace std;


class View
{
  public:
    void menu(vector<string>&, int& choice);
    void getNumber(int& num);
  
};

#endif
