Name: Umar Jan

Student Number: 101270578

Files:
	App.cc
	App.h	
	AppArray.cc
	AppArray.h
	AppMarket.cc
	AppMarket.h
	classa2.py
	Control.cc
	Control.h
	defs.h
	Device.cc
	Device.h
	DeviceArray.cc
	DeviceArray.h
	DeviceManager.cc
	DeviceManager.h
	main.cc
	Makefile	
	README.txt
	TestControl.cc
	TestControl.h
	Tester.cc
	Tester.h
	testmain.cc
	View.cc
	View.h

Compilation instructions:
	Open terminal in folder, Run "make" command, 

To execute: 	
	use command: ./a2
	use command: ./a2test
		