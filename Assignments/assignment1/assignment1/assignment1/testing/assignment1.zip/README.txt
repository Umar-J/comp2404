Name:
Umar Jan

Student Number:
101270578

Files: 
Date.cc
Date.h
defs.h
Event.cc
Event.h
main.cc
Makefile
Planner.cc
Planner.h
PlannerDate.cc
PlannerDate.h
README.txt
Tester.h

Compilation instructions:
Open terminal in folder, Run "make" command, run output file with terminal command: "./a1"    ** note: do not enter the (")