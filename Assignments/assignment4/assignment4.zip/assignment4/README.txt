Name: Umar Jan

Student Number: 101270578

Files: 
	Array.h         
	Controller.cc  
	Episode.h  
	Podcast.cc        
	PodcastPlayer.cc  
	README.txt            
	Tester.cc       
	videos
	Controller.h   
	main.cc    
	PodcastFactory.cc 
	PodcastPlayer.h   
	Search.cc   
	test.cc         
	Tester.h        
	View.cc
	defs.h         
	Makefile   
	PodcastFactory.h   
	Podify.cc         
	Search.h    
	TestControl.cc  
	View.h
	classa2.py      
	Episode.cc    
	media      
	Podcast.h          
	Podify.h          
	test       
	TestControl.h   


Compilation instructions:
	Open terminal in folder, Run "make" command, 

To execute: 	
	use command: ./a4
	use command: ./test