#include <iostream>
#include <limits>
#include "Calendar.h"
using namespace std;

void addDate(Calendar&);
void printCalendar(Calendar&);
void printCalendar(Calendar*);

int main()
{ 


  return 0;
}

void addDate(Calendar& cal)
{
  cout << "Please enter Date: YYYY MM DD" << endl;

  int y, m, d;
  cin>>y>>m>>d;
  cal.addDate(y,m,d);

}


void printCalendar(Calendar& cal)
{
  cal.print();
}

void printCalendar(Calendar* cal)
{
  cal->print();
}



