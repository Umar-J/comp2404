#include "Calendar.h"

Calendar::Calendar(){

}

Calendar::~Calendar(){
    // Delete all Dates we are storing.
    // This will prevent memory leaks

    
    
}

bool Calendar::addDate(int y, int m, int d){
    if (numDates >= MAX_ARRAY) return false;
    
     
}

bool Calendar::removeDate(int y, int m, int d){
    
    return true;
}

 Date* Calendar::getDate(int index){
    
}

void Calendar::print(){
    cout<<endl<<"Printing all dates: "<<endl;
    
    
}