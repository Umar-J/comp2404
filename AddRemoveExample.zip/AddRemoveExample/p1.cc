#include <iostream>
#include <string>

#define NUMSTUDENTS 3
using namespace std;

#include "University.h"
/**************************************
 * Student database for a university  *
 * with some associated operations.   *
 * ************************************/


int main(){

    //Student database
    string names[NUMSTUDENTS] = {"Joe", "Amy", "Barb"};
    string numbers[NUMSTUDENTS] = {"101111111", "101222222", "101333333"};
    string major[NUMSTUDENTS] = {"CS", "Math", "History"};
    float gpa[NUMSTUDENTS] = {10.0f, 11.2f, 5.9f};

    University carl("Carleton");

    cout<<"Adding students:"<<endl;
    //initializes
    for (int i = 0; i < NUMSTUDENTS; ++i){
        carl.addStudent(names[i], numbers[i], major[i], gpa[i]);
    }


    cout<<"Printing all students:"<<endl;

    carl.print();

    cout<<"Removing student Amy"<<endl;

    carl.removeStudent("Amy");

    cout<<"Printing all students:"<<endl;

    carl.print();

     cout<<"Removing student Joe"<<endl;

    carl.removeStudent("Joe");

    cout<<"Printing all students:"<<endl;

    carl.print();

    cout<<"Removing student Jean"<<endl;

    carl.removeStudent("Jean");

    cout<<"Printing all students:"<<endl;

    carl.print();

    cout<<"Removing student Barb"<<endl;

    carl.removeStudent("Barb");

    cout<<"Printing all students:"<<endl;

    carl.print();


}
