#include "University.h"


University::University(string name){
    this->name = name;
    numStudents = 0;
}

bool University::addStudent(string name, string number, string major, float gpa){
    if (numStudents >= MAX_ARR){
        return false;
    }
    cout<<"Adding student "<<name<<endl;
    cout<<"numStudents = "<<numStudents<<endl;
    
    Student* stu = new Student(name, number, major, gpa);

    int index = 0;  // index where we will add stu

    while (index < numStudents){
        if (stu->lessThan(*students[index])){
            // this is the place - make some room
            for (int i = numStudents; i > index; --i){
                students[i] = students[i-1];
            }
            break;
        }
        ++index;
    }

    cout<<"Adding student "<<name<<" at index "<<index<<endl;
    students[index] = stu;
    ++ numStudents;
    return true;
}

bool University::removeStudent(string name){
    int index = 0;
    while (index < numStudents){
        if (students[index]->equals(name)){
            // found it
            break;
        }
        ++index;
    }
    if (index == numStudents){
        // didn't find it
        return false;
    }
    // found it at index
    cout<<"Removing student "<<name<<" at index "<<index<<endl;
    delete students[index];
    --numStudents;
    for (int i = index; i < numStudents; ++i){
        students[i] = students[i+1];
    }
    return true;
}

void University::print(){
    cout << "University: " << name << endl;
    cout << "Students: " << endl;
    for (int i = 0; i < numStudents; ++i){
        students[i]->print();
        cout<<endl;
    }
}