#ifndef UNIVERSITY_H
#define UNIVERSITY_H

#include <iostream>
#include <string>
#include "Student.h"

#define MAX_ARR 100


using namespace std;

class University{
    public:
        University(string name);
        
        bool addStudent(string name, string number, string major, float gpa);

        bool removeStudent(string name);
        
        void print();

    private:
        string name;
        int numStudents;
        Student* students[MAX_ARR];


};

#endif