#include "Student.h"

Student::Student(string name, string number, string major, float gpa) {
    this->name = name;
    this->number = number;
    this->major = major;
    this->gpa = gpa;
}

void Student::print() {
    cout << "Name:   " << name << endl;
    cout << "Number: " << number << endl;
    cout << "Major:  " << major << endl;
    cout << "GPA:    " << gpa << endl;
}


bool Student::isPassing() {
    return gpa >= 6.0;
}